from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask import  Flask, send_from_directory
from flask_mysqldb import MySQL
import pandas as pd
import os
app = Flask(__name__, static_folder='static')

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'super_d1'
mysql = MySQL(app)
app.secret_key = 'votre_cle_secrete'



@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        uname = request.form["uname"]  # Username entered
        passw = request.form["passw"]  # Password entered

        # Query the database to check if the username and password match
        cur = mysql.connection.cursor()
        cur.execute('SELECT * FROM user WHERE username = %s AND password = %s', (uname, passw))
        user = cur.fetchone()
        cur.close()

        if user:
            # Store the username in the session
            session['username'] = uname

            # Check if the user is the admin (using the fixed admin credentials)
            if uname == "mohamed" and passw == "44444444":  # Only the fixed admin credentials
                return redirect(url_for('match_results'))  # Redirect to the match results for admin
            else:
                return redirect(url_for('match_results_user'))  # Redirect to the user-specific page

        else:
            flash("Invalid username or password", "error")  # Login failed

    return render_template("login2.html")




@app.route('/match_results')
def match_results():
    # Fixed admin credentials
    admin_username = "mohamed"
    admin_password = "44444444"  # Replace with a strong password

    # Check if the session matches the admin credentials
    if 'username' not in session or session['username'] != admin_username:
        return redirect(url_for('login'))  # Redirect to login if not admin

    # Fetch match results for admin
    cur = mysql.connection.cursor()
    cur.execute("""SELECT 
                        m.id_semaine, 
                        e1.Nom_equipe AS team1, 
                        e1.logo_url AS team1_logo, 
                        e2.Nom_equipe AS team2, 
                        e2.logo_url AS team2_logo, 
                        m.Score_equipe1, 
                        m.Score_equipe2, 
                        DATE_FORMAT(m.date, '%Y-%m-%d') AS formatted_date,
                        m.ID_match
                    FROM matchs AS m
                    JOIN classement AS e1 ON m.ID_equipe1 = e1.ID_equipe
                    JOIN classement AS e2 ON m.ID_equipe2 = e2.ID_equipe
                    ORDER BY m.id_semaine, m.ID_match""")
    data = cur.fetchall()
    cur.close()

    return render_template('list_Med.html', QP=data)


@app.route('/match_results_user')
def match_results_user():
    # Fetch match results for normal users
    cur = mysql.connection.cursor()
    cur.execute("""SELECT 
                        m.id_semaine, 
                        e1.Nom_equipe AS team1, 
                        e1.logo_url AS team1_logo, 
                        e2.Nom_equipe AS team2, 
                        e2.logo_url AS team2_logo, 
                        m.Score_equipe1, 
                        m.Score_equipe2, 
                        DATE_FORMAT(m.date, '%Y-%m-%d') AS formatted_date,
                        m.ID_match
                    FROM matchs AS m
                    JOIN classement AS e1 ON m.ID_equipe1 = e1.ID_equipe
                    JOIN classement AS e2 ON m.ID_equipe2 = e2.ID_equipe
                    ORDER BY m.id_semaine, m.ID_match""")
    data2 = cur.fetchall()
    cur.close()
    return render_template('list_Med_user.html', QP=data2)






@app.route("/oublier", methods=["GET", "POST"])
def motpass():
    if request.method == "POST":
        mail = request.form["email"]

        conn2 = mysql.connection.cursor()
        cur = mysql.connection.cursor()

        cur.execute(
            'SELECT email FROM user')
        data = cur.fetchall()
        l = list()
        i2 = 0
        for i in data:
            l.append(i[i2])

        if l.index(mail) != -1:
            flash("cree un nauveau compte!")
            return redirect(url_for('register'))
        else:
            flash("votre mail est faux")
    return render_template("oublier.html")

@app.route('/static/<path:path>')
def static_files(path):
    return send_from_directory('../../static', path)


def update_classement(equipe, buts_marques, buts_encaisses, resultat):
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT Matches_joues, Victoires, Nuls, Defaites, Points, Buts_marques, Buts_encaisses 
        FROM classement WHERE Nom_equipe = %s
    """, (equipe,))
    stats = cur.fetchone()
    if stats:
        matches_joues, victoires, nuls, defaites, points, buts_marques_totaux, buts_encaisses_totaux = stats
        matches_joues += 1
        buts_marques_totaux += buts_marques
        buts_encaisses_totaux += buts_encaisses
        if resultat == 'victoire':
            victoires += 1
            points += 3
        elif resultat == 'nul':
            nuls += 1
            points += 1
        elif resultat == 'defaite':
            defaites += 1
        cur.execute("""
            UPDATE classement
            SET Matches_joues = %s, Victoires = %s, Nuls = %s, Defaites = %s, Points = %s, 
                Buts_marques = %s, Buts_encaisses = %s
            WHERE Nom_equipe = %s
        """, (matches_joues, victoires, nuls, defaites, points, buts_marques_totaux, buts_encaisses_totaux, equipe))
        mysql.connection.commit()
    cur.close()
def process_excel(file_path):
    try:
        # قراءة ملف Excel باستخدام pandas
        df = pd.read_excel(file_path)

        # التحقق من الأعمدة المطلوبة
        required_columns = ['Equipe1', 'Equipe2', 'Score1', 'Score2', 'Date', 'Semaine']
        if not all(col in df.columns for col in required_columns):
            return "الملف لا يحتوي على الأعمدة المطلوبة: Equipe1, Equipe2, Score1, Score2, Date, Semaine."

        # إدخال البيانات إلى قاعدة البيانات
        cur = mysql.connection.cursor()
        for _, row in df.iterrows():
            equipe1 = row['Equipe1']
            equipe2 = row['Equipe2']
            score1 = int(row['Score1'])
            score2 = int(row['Score2'])
            match_date = row['Date']
            semaine = int(row['Semaine'])

            # إدخال المباراة
            cur.execute("""
                INSERT INTO matchs (ID_equipe1, ID_equipe2, Score_equipe1, Score_equipe2, id_semaine, date)
                VALUES (
                    (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s),
                    (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s),
                    %s, %s, %s, %s
                )
            """, (equipe1, equipe2, score1, score2, semaine, match_date))

            # تحديث ترتيب الفريقين بناءً على النتيجة
            if score1 > score2:
                update_classement(equipe1, score1, score2, 'victoire')
                update_classement(equipe2, score2, score1, 'defaite')
            elif score1 < score2:
                update_classement(equipe2, score2, score1, 'victoire')
                update_classement(equipe1, score1, score2, 'defaite')
            else:
                update_classement(equipe1, score1, score2, 'nul')
                update_classement(equipe2, score2, score1, 'nul')

        mysql.connection.commit()
        cur.close()
        return "تمت معالجة البيانات بنجاح."
    except Exception as e:
        return f"خطأ أثناء معالجة الملف: {e}"

# مسار لتحميل ملف Excel
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        if not file:
            flash("يرجى اختيار ملف Excel.", "error")
            return redirect(url_for('upload'))

        file_path = os.path.join('../../uploads', file.filename)
        os.makedirs('../../uploads', exist_ok=True)
        file.save(file_path)

        result_message = process_excel(file_path)
        flash(result_message, "success")
        return redirect(url_for('upload'))

    return render_template('upload.html')

@app.route('/classement')
def Index():
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT 
            Nom_equipe,
            Matches_joues,
            Victoires,
            Nuls,
            Defaites,
            Points,
            Buts_marques,
            Buts_encaisses,
            logo_url
        FROM 
            classement
        ORDER BY 
            Points DESC, 
            Victoires DESC
    """)
    data = cur.fetchall()
    cur.close()
    total_matches = sum(row[1] for row in data)
    total_wins = sum(row[2] for row in data)
    total_draws = sum(row[3] for row in data)
    total_losses = sum(row[4] for row in data)
    return render_template('list_pt.html', EQPS=data,
                           total_matches=total_matches,
                           total_wins=total_wins,
                           total_draws=total_draws,
                           total_losses=total_losses)


@app.route('/add_match', methods=['GET', 'POST'])
def add_match():
    # Check if the current user is an admin
    if 'username' not in session or session['username'] != "mohamed":
        flash("Vous devez être administrateur pour accéder à cette page.", "error")
        return redirect(url_for('login'))  # Redirect to login if not admin

    cur = mysql.connection.cursor()
    cur.execute("SELECT Nom_equipe FROM classement")
    equipes = cur.fetchall()
    cur.close()

    if request.method == 'POST':
        equipe_a = request.form['equipe_a']
        equipe_b = request.form['equipe_b']
        try:
            score_a = int(request.form['score_equipe1'])
            score_b = int(request.form['score_equipe2'])
            semaine = int(request.form['id_semaine'])
            if semaine < 0:
                raise ValueError()
        except ValueError:
            flash("Les scores et la semaine doivent être numériques et positifs.", "error")
            return render_template('IndexMed.html', equipes=equipes)

        match_date = request.form['date']

        if not all([equipe_a, equipe_b, score_a, score_b, semaine, match_date]):
            flash("Tous les champs sont obligatoires !", "error")
            return render_template('IndexMed.html', equipes=equipes)

        if semaine > 24 or semaine < 1:
            flash("La semaine doit être comprise entre 1 et 24.", "error")
            return render_template('IndexMed.html', equipes=equipes)

        if equipe_a == equipe_b:
            flash("Erreur: une équipe ne peut pas jouer contre elle-même.", "error")
            return render_template('IndexMed.html', equipes=equipes)

        cur = mysql.connection.cursor()
        cur.execute(""" 
            SELECT COUNT(*) 
            FROM matchs 
            WHERE id_semaine = %s 
            AND (ID_equipe1 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s) 
            OR ID_equipe2 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s))
        """, (semaine, equipe_a, equipe_a))
        match_count_a = cur.fetchone()[0]

        cur.execute(""" 
            SELECT COUNT(*) 
            FROM matchs 
            WHERE id_semaine = %s 
            AND (ID_equipe1 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s) 
            OR ID_equipe2 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s))
        """, (semaine, equipe_b, equipe_b))
        match_count_b = cur.fetchone()[0]

        if match_count_a > 0:
            flash(f"L'équipe {equipe_a} ne peut pas jouer plus d'une fois dans la même semaine.", "error")
            return render_template('IndexMed.html', equipes=equipes)

        if match_count_b > 0:
            flash(f"L'équipe {equipe_b} ne peut pas jouer plus d'une fois dans la même semaine.", "error")
            return render_template('IndexMed.html', equipes=equipes)

        cur.execute(""" 
            INSERT INTO matchs (ID_equipe1, ID_equipe2, Score_equipe1, Score_equipe2, id_semaine, date)
            VALUES (
                (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s),
                (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s),
                %s, %s, %s, %s
            )
        """, (equipe_a, equipe_b, score_a, score_b, semaine, match_date))

        if score_a > score_b:
            cur.execute(""" 
                UPDATE classement 
                SET Points = Points + 3, Victoires = Victoires + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE Nom_equipe = %s
            """, (score_a, score_b, equipe_a))
            cur.execute(""" 
                UPDATE classement 
                SET Defaites = Defaites + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE Nom_equipe = %s
            """, (score_b, score_a, equipe_b))
        elif score_a < score_b:
            cur.execute(""" 
                UPDATE classement 
                SET Points = Points + 3, Victoires = Victoires + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE Nom_equipe = %s
            """, (score_b, score_a, equipe_b))
            cur.execute(""" 
                UPDATE classement 
                SET Defaites = Defaites + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE Nom_equipe = %s
            """, (score_a, score_b, equipe_a))
        else:
            cur.execute(""" 
                UPDATE classement 
                SET Points = Points + 1, Nuls = Nuls + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE Nom_equipe = %s
            """, (score_a, score_b, equipe_a))
            cur.execute(""" 
                UPDATE classement 
                SET Points = Points + 1, Nuls = Nuls + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE Nom_equipe = %s
            """, (score_b, score_a, equipe_b))

        mysql.connection.commit()
        cur.close()
        flash("Le match a été ajouté avec succès.", "success")
        return redirect(url_for('Index'))

    return render_template('IndexMed.html', equipes=equipes)




@app.route('/get_available_rounds', methods=['GET'])
def get_available_rounds():
    equipe_a = request.args.get('equipe_a')
    equipe_b = request.args.get('equipe_b')

    if not equipe_a or not equipe_b:
        return {"rounds": []}

    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT id_semaine 
        FROM matchs 
        WHERE ID_equipe1 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s)
        OR ID_equipe2 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s)
    """, (equipe_a, equipe_a))
    rounds_a = {row[0] for row in cur.fetchall()}

    cur.execute("""
        SELECT id_semaine 
        FROM matchs 
        WHERE ID_equipe1 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s)
        OR ID_equipe2 = (SELECT ID_equipe FROM classement WHERE Nom_equipe = %s)
    """, (equipe_b, equipe_b))
    rounds_b = {row[0] for row in cur.fetchall()}

    cur.close()

    all_rounds = set(range(1, 25))
    available_rounds = list(all_rounds - rounds_a - rounds_b)

    return {"rounds": sorted(available_rounds)}






@app.route('/modifie_match/<int:match_id>', methods=['GET', 'POST'])
def modifie_match(match_id):
    cur = mysql.connection.cursor()

    if request.method == 'POST':
        # جلب القيم الجديدة من النموذج
        new_score_a = int(request.form['score_equipe1'])
        new_score_b = int(request.form['score_equipe2'])
        new_date_match = request.form['date']

        # جلب بيانات المباراة الأصلية
        cur.execute("""
            SELECT ID_equipe1, ID_equipe2, Score_equipe1, Score_equipe2 
            FROM matchs 
            WHERE ID_match = %s
        """, (match_id,))
        old_match = cur.fetchone()

        if not old_match:
            flash("المباراة غير موجودة.", "error")
            return redirect(url_for('match_results'))

        id_equipe1, id_equipe2, old_score_a, old_score_b = old_match

        # عكس تأثير النتيجة القديمة على الترتيب
        if old_score_a > old_score_b:
            # فريق 1 كان الفائز
            cur.execute("""
                UPDATE classement 
                SET Points = GREATEST(0, Points - 3), Victoires = GREATEST(0, Victoires - 1), Matches_joues = GREATEST(0, Matches_joues - 1),
                    Buts_marques = GREATEST(0, Buts_marques - %s), Buts_encaisses = GREATEST(0, Buts_encaisses - %s)
                WHERE ID_equipe = %s
            """, (old_score_a, old_score_b, id_equipe1))
            cur.execute("""
                UPDATE classement 
                SET Defaites = GREATEST(0, Defaites - 1), Matches_joues = GREATEST(0, Matches_joues - 1),
                    Buts_marques = GREATEST(0, Buts_marques - %s), Buts_encaisses = GREATEST(0, Buts_encaisses - %s)
                WHERE ID_equipe = %s
            """, (old_score_b, old_score_a, id_equipe2))
        elif old_score_a < old_score_b:
            # فريق 2 كان الفائز
            cur.execute("""
                UPDATE classement 
                SET Points = GREATEST(0, Points - 3), Victoires = GREATEST(0, Victoires - 1), Matches_joues = GREATEST(0, Matches_joues - 1),
                    Buts_marques = GREATEST(0, Buts_marques - %s), Buts_encaisses = GREATEST(0, Buts_encaisses - %s)
                WHERE ID_equipe = %s
            """, (old_score_b, old_score_a, id_equipe2))
            cur.execute("""
                UPDATE classement 
                SET Defaites = GREATEST(0, Defaites - 1), Matches_joues = GREATEST(0, Matches_joues - 1),
                    Buts_marques = GREATEST(0, Buts_marques - %s), Buts_encaisses = GREATEST(0, Buts_encaisses - %s)
                WHERE ID_equipe = %s
            """, (old_score_a, old_score_b, id_equipe1))
        else:
            # المباراة كانت تعادل
            cur.execute("""
                UPDATE classement 
                SET Points = GREATEST(0, Points - 1), Nuls = GREATEST(0, Nuls - 1), Matches_joues = GREATEST(0, Matches_joues - 1),
                    Buts_marques = GREATEST(0, Buts_marques - %s), Buts_encaisses = GREATEST(0, Buts_encaisses - %s)
                WHERE ID_equipe = %s
            """, (old_score_a, old_score_b, id_equipe1))
            cur.execute("""
                UPDATE classement 
                SET Points = GREATEST(0, Points - 1), Nuls = GREATEST(0, Nuls - 1), Matches_joues = GREATEST(0, Matches_joues - 1),
                    Buts_marques = GREATEST(0, Buts_marques - %s), Buts_encaisses = GREATEST(0, Buts_encaisses - %s)
                WHERE ID_equipe = %s
            """, (old_score_b, old_score_a, id_equipe2))

        # تحديث النتائج الجديدة
        cur.execute("""
            UPDATE matchs
            SET Score_equipe1 = %s, Score_equipe2 = %s, date = %s
            WHERE ID_match = %s
        """, (new_score_a, new_score_b, new_date_match, match_id))

        # تطبيق تأثير النتيجة الجديدة
        if new_score_a > new_score_b:
            cur.execute("""
                UPDATE classement 
                SET Points = Points + 3, Victoires = Victoires + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE ID_equipe = %s
            """, (new_score_a, new_score_b, id_equipe1))
            cur.execute("""
                UPDATE classement 
                SET Defaites = Defaites + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE ID_equipe = %s
            """, (new_score_b, new_score_a, id_equipe2))
        elif new_score_a < new_score_b:
            cur.execute("""
                UPDATE classement 
                SET Points = Points + 3, Victoires = Victoires + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE ID_equipe = %s
            """, (new_score_b, new_score_a, id_equipe2))
            cur.execute("""
                UPDATE classement 
                SET Defaites = Defaites + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE ID_equipe = %s
            """, (new_score_a, new_score_b, id_equipe1))
        else:
            cur.execute("""
                UPDATE classement 
                SET Points = Points + 1, Nuls = Nuls + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE ID_equipe = %s
            """, (new_score_a, new_score_b, id_equipe1))
            cur.execute("""
                UPDATE classement 
                SET Points = Points + 1, Nuls = Nuls + 1, Matches_joues = Matches_joues + 1,
                    Buts_marques = Buts_marques + %s, Buts_encaisses = Buts_encaisses + %s
                WHERE ID_equipe = %s
            """, (new_score_b, new_score_a, id_equipe2))

        mysql.connection.commit()
        cur.close()

        flash("تم تعديل نتائج المباراة وجداول الترتيب بنجاح.", "success")
        return redirect(url_for('match_results'))

    # جلب بيانات المباراة الحالية
    cur.execute("""
        SELECT m.Score_equipe1, m.Score_equipe2, m.date, 
               e1.Nom_equipe AS equipe_a, e2.Nom_equipe AS equipe_b
        FROM matchs AS m
        JOIN classement AS e1 ON m.ID_equipe1 = e1.ID_equipe
        JOIN classement AS e2 ON m.ID_equipe2 = e2.ID_equipe
        WHERE m.ID_match = %s
    """, (match_id,))
    match = cur.fetchone()
    cur.close()

    return render_template('list_Dg.html', match={
        'Score_equipe1': match[0],
        'Score_equipe2': match[1],
        'date': match[2],
        'equipe_a': match[3],
        'equipe_b': match[4]
    }, match_id=match_id)








app.debug = True

app.run(host='0.0.0.0', port=5000)

