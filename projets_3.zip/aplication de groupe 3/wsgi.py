from  notre_projet import app

if __name__ == "main":
    app.run