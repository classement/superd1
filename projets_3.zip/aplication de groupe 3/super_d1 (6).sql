-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 17, 2025 at 04:49 PM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `super_d1`
--

-- --------------------------------------------------------

--
-- Table structure for table `classement`
--

DROP TABLE IF EXISTS `classement`;
CREATE TABLE IF NOT EXISTS `classement` (
  `ID_equipe` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_equipe` varchar(100) NOT NULL,
  `Matches_joues` int(11) DEFAULT '0',
  `Victoires` int(11) DEFAULT '0',
  `Nuls` int(11) DEFAULT '0',
  `Defaites` int(11) DEFAULT '0',
  `Points` int(11) DEFAULT '0',
  `logo_url` varchar(255) NOT NULL,
  `Buts_marques` int(11) DEFAULT '0',
  `Buts_encaisses` int(11) DEFAULT '0',
  PRIMARY KEY (`ID_equipe`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classement`
--

INSERT INTO `classement` (`ID_equipe`, `Nom_equipe`, `Matches_joues`, `Victoires`, `Nuls`, `Defaites`, `Points`, `logo_url`, `Buts_marques`, `Buts_encaisses`) VALUES
(2, 'NDB', 9, 4, 2, 3, 14, 'http://127.0.0.1:5001/static/logos/NDB.png', 3357, 24),
(1, 'SNIM', 5, 2, 2, 1, 8, 'http://127.0.0.1:5001/static/logos/SNIM.png', 13, 9),
(3, 'CHEMAL', 2, 1, 1, 0, 4, 'http://127.0.0.1:5001/static/logos/CHL.png', 10, 3),
(4, 'DWANE', 3, 0, 1, 2, 1, 'http://127.0.0.1:5001/static/logos/DWN.png', 1, 9),
(5, 'GARDE', 1, 0, 1, 0, 1, 'http://127.0.0.1:5001/static/logos/GRD.png', 1, 1),
(6, 'INTER NKTT', 2, 0, 1, 1, 1, 'http://127.0.0.1:5001/static/logos/INTER.png', 2, 6),
(7, 'NKTT KING', 0, 0, 0, 0, 0, 'http://127.0.0.1:5001/static/logos/KING.png', 0, 0),
(8, 'POMPERS', 1, 0, 0, 1, 0, 'http://127.0.0.1:5001/static/logos/POP.png', 0, 3333),
(9, 'FC KSR', 2, 1, 0, 1, 3, 'http://127.0.0.1:5001/static/logos/KSR.png', 4, 7),
(10, 'Tevragh-Zeina', 1, 1, 0, 0, 3, 'http://127.0.0.1:5001/static/logos/TVZ.png', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `matchs`
--

DROP TABLE IF EXISTS `matchs`;
CREATE TABLE IF NOT EXISTS `matchs` (
  `ID_match` int(11) NOT NULL AUTO_INCREMENT,
  `id_semaine` int(11) NOT NULL,
  `ID_equipe1` int(11) NOT NULL,
  `ID_equipe2` int(11) NOT NULL,
  `Score_equipe1` int(11) DEFAULT '0',
  `Score_equipe2` int(11) DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_match`),
  KEY `id_semaine` (`id_semaine`),
  KEY `ID_equipe1` (`ID_equipe1`),
  KEY `ID_equipe2` (`ID_equipe2`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `matchs`
--

INSERT INTO `matchs` (`ID_match`, `id_semaine`, `ID_equipe1`, `ID_equipe2`, `Score_equipe1`, `Score_equipe2`, `date`) VALUES
(73, 6, 2, 3, 2, 9, '2025-01-02 00:00:00'),
(76, 9, 2, 4, 6, 0, '2025-01-02 00:00:00'),
(80, 5, 2, 6, 1, 1, '2025-01-04 00:00:00'),
(78, 3, 2, 1, 6, 9, '2025-01-03 00:00:00'),
(79, 8, 1, 2, 0, 0, '2025-01-03 00:00:00'),
(74, 4, 3, 1, 1, 1, '2025-01-03 00:00:00'),
(81, 10, 2, 8, 3333, 0, '2025-01-08 00:00:00'),
(82, 2, 10, 9, 5, 1, '2025-01-17 00:00:00'),
(83, 7, 2, 6, 5, 1, '2025-01-16 00:00:00'),
(84, 1, 2, 1, 2, 1, '2024-12-29 00:00:00'),
(85, 1, 2, 1, 2, 1, '2024-01-01 00:00:00'),
(86, 23, 2, 1, 2, 1, '2025-01-20 00:00:00'),
(87, 23, 2, 1, 2, 1, '2025-01-20 00:00:00'),
(88, 23, 2, 1, 2, 1, '2025-01-20 00:00:00'),
(89, 23, 4, 5, 1, 1, '2025-01-21 00:00:00'),
(90, 24, 9, 2, 3, 2, '2025-01-22 00:00:00'),
(91, 24, 1, 4, 2, 0, '2025-01-23 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `password`, `role`, `email`) VALUES
(8, 'scrypt:32768:8:1$UZMrnWUPeRUMfSeJ$ebbcb8159b4897368109c99d3a71400ff411f87104a09f25f931c89a6539f44e7e8df520f91d74deee93b5b7fbf46b2b417c25fb9ce87e55f512f66d3bc09b51', 'admin', '23637@esp.mr'),
(4, '{22075279}', 'admin', NULL),
(5, 'scrypt:32768:8:1$SNHGP0aHvpNdRxy4$57d1563d04025b2c4f33f8db524f972cf144edf6d2c6657579ca85d0e0c2fe94f9c3748bbf046fd1976f50e859ed314e00a0a5fae534d0bcb25c53ae8589c355', 'user', NULL),
(6, 'scrypt:32768:8:1$tDztZQED3vGCJFqW$2e8ad68524a0c11cc1987fa6f7584fe1f25cc7c3fb2c5046796ec3c9caefb88e46a02fba42a1032fdbfb3392257edb09010d17d5269a3b1b2af86d45cddd49b4', 'user', NULL),
(7, 'scrypt:32768:8:1$ObNBEpnUG1aBySD0$015105340de6bc48426e2af44fe778bd54ff31e378c9c15f453932eef72909266413b8a2c83d1ee2d7c31eddb3cead670d9069104e4482bbf6e127a832a000c7', 'admin', 'CHEIKHNE@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
